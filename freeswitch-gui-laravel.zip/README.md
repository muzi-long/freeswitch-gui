### 基于laravel6.0与freeswitch1.8版本的外呼平台
## 安装步骤
- git clone  xxxxx
- 复制.env.example为.env
- 配置.env里的数据库连接信息
- composer update
- php artisan migrate
- php artisan db:seed
- php artisan key:generate
- 登录后台：host/admin   帐号：root  密码：123456

