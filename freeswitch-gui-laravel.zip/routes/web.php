<?php

/*
|--------------------------------------------------------------------------
| 前台路由
|--------------------------------------------------------------------------
|
| 统一命名空间 Home
| 统一前缀 home
| 用户认证统一使用 merchant 中间件
| 权限认证统一使用 permission:权限名称
|
*/


/*
|--------------------------------------------------------------------------
| 用户登录、退出、更改密码
|--------------------------------------------------------------------------
*/
Route::group(['namespace'=>'Home','prefix'=>'home/user'],function (){
    //登录
    Route::get('login','UserController@showLoginForm')->name('home.user.loginForm');
    Route::post('login','UserController@login')->name('home.user.login');
    //退出
    Route::get('logout','UserController@logout')->name('home.user.logout')->middleware('member');
    //更改密码
    Route::get('change_my_password_form','UserController@changeMyPasswordForm')->name('home.user.changeMyPasswordForm')->middleware('member');
    Route::post('change_my_password','UserController@changeMyPassword')->name('home.user.changeMyPassword')->middleware('member');
});


/*
|--------------------------------------------------------------------------
| 前台公共页面
|--------------------------------------------------------------------------
*/
Route::group(['namespace'=>'Home','prefix'=>'home','middleware'=>'member'],function (){
    //后台布局
    Route::get('/','IndexController@layout')->name('home.layout');
    //后台首页
    Route::get('/index','IndexController@index')->name('home.index');
});

