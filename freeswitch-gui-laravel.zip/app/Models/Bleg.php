<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Bleg extends Model
{
    protected $table = 'cdr_b_leg';
}
