<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Asr extends Model
{
    protected $table = 'cdr_asr';
}
