<?php $__env->startSection('content'); ?>
    <style>
        .layui-form-checkbox span{width: 100px}
    </style>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>分配角色</h2>
        </div>
        <div class="layui-card-body">
            <form class="layui-form" action="<?php echo e(route('home.member.assignRole',['id'=>$member->id])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('put')); ?>

                <div class="layui-form-item">
                    <label for="" class="layui-form-label">帐号</label>
                    <div class="layui-word-aux layui-form-mid"><?php echo e($member->username); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">联系人</label>
                    <div class="layui-word-aux layui-form-mid"><?php echo e($member->contact_name); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">联系电话</label>
                    <div class="layui-word-aux layui-form-mid"><?php echo e($member->contact_phone); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">角色</label>
                    <div class="layui-input-block" style="width: 700px">
                        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" title="<?php echo e($role->display_name); ?>" <?php echo e($role->own ? 'checked' : ''); ?> >
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="layui-form-mid layui-word-aux">还没有角色</div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button type="submit" class="layui-btn" lay-submit="" lay-filter="formDemo">确 认</button>
                        <a class="layui-btn" href="<?php echo e(route('home.member')); ?>" >返 回</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        layui.use(['element','form'],function () {

        })
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/home/member/role.blade.php ENDPATH**/ ?>