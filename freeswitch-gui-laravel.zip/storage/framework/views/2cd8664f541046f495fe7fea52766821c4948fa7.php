<script>
    layui.config({
        base: '/static/admin/layuiadmin/modules/'
    }).extend({
        selectN: 'select-ext/selectN'
    }).use(['layer','table','form','selectN'],function () {
        var $ = layui.jquery;
        var layer = layui.layer;
        var form = layui.form;
        var table = layui.table;
        var selectN = layui.selectN;

    })
</script><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/home/sip/_js.blade.php ENDPATH**/ ?>