<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>商户详情</h2>
            <div class="layui-form">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label for="" class="layui-form-label">帐号</label>
                        <div class="layui-form-mid layui-word-aux" style="width: 140px">
                            <?php echo e($merchant->username); ?>

                        </div>
                    </div>
                    <div class="layui-inline">
                        <label for="" class="layui-form-label">公司名称</label>
                        <div class="layui-form-mid layui-word-aux" style="width: 140px">
                            <?php echo e($merchant->company_name); ?>

                        </div>
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label for="" class="layui-form-label">分机数</label>
                        <div class="layui-form-mid layui-word-aux" style="width: 140px">
                            共<?php echo e($merchant->sip_num); ?>个
                        </div>
                    </div>
                    <div class="layui-inline">
                        <label for="" class="layui-form-label">子帐号数</label>
                        <div class="layui-form-mid layui-word-aux" style="width: 140px">
                            共<?php echo e($merchant->account_num); ?>个
                        </div>
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label for="" class="layui-form-label">状态</label>
                        <div class="layui-form-mid layui-word-aux" style="width: 140px">
                            <?php echo e($merchant->status_name); ?>

                        </div>
                    </div>
                    <div class="layui-inline">
                        <label for="" class="layui-form-label">到期时间</label>
                        <div class="layui-form-mid layui-word-aux" style="width: 140px">
                            <?php echo e($merchant->expires_at); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
                <ul class="layui-tab-title">
                    <li class="layui-this">网关</li>
                    <li >子帐号</li>
                    <li >分机</li>
                </ul>
                <div class="layui-tab-content">
                    <div class="layui-tab-item layui-show">
                        <form class="layui-form" action="<?php echo e(route('admin.merchant.assignGateway',['id'=>$merchant->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <div class="layui-form-item">
                                <table class="layui-table" lay-size="sm">
                                    <thead>
                                    <tr>
                                        <th width="20"><input type="checkbox" lay-ignore lay-skin="primary" id="checkAll" ></th>
                                        <th>网关名称</th>
                                        <th>网关帐号</th>
                                        <th>注册地址</th>
                                        <th width="100">费率（元/分钟）</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><input type="checkbox" class="checkItem" lay-ignore name="gateways[<?php echo e($loop->index); ?>][id]" value="<?php echo e($gateway->id); ?>" <?php if($merchant->gateways->contains($gateway)): ?> checked <?php endif; ?> ></td>
                                            <td><?php echo e($gateway->name); ?></td>
                                            <td><?php echo e($gateway->username); ?></td>
                                            <td><?php echo e($gateway->realm); ?></td>
                                            <td><input type="text" name="gateways[<?php echo e($loop->index); ?>][rate]" value="<?php echo e($gateway->rate); ?>" class="layui-input" lay-verify="required|number" style="height:26px;line-height: 26px"></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><td colspan="5">没有可分配的网关，请联系管理员</td></tr>
                                    </tbody>
                                    <?php endif; ?>
                                </table>
                            </div>
                            <div class="layui-form-item">
                                <button type="submit" class="layui-btn" lay-submit="" lay-filter="formDemo">确 认</button>
                                <a class="layui-btn" href="<?php echo e(route('admin.merchant')); ?>" >返 回</a>
                            </div>
                        </form>
                    </div>
                    <div class="layui-tab-item">
                        <table class="layui-table" lay-size="sm">
                            <thead>
                            <tr>
                                <th>帐号</th>
                                <th>昵称</th>
                                <th>状态</th>
                                <th>分机号</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($val->username); ?></td>
                                    <td><?php echo e($val->nickname); ?></td>
                                    <td><?php echo e($val->status_name); ?></td>
                                    <td><?php echo e($val->sip->username); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4">无数据</td></tr>
                            </tbody>
                            <?php endif; ?>
                        </table>
                    </div>
                    <div class="layui-tab-item">
                        <table class="layui-table" lay-size="sm">
                            <thead>
                            <tr>
                                <th>帐号</th>
                                <th>密码</th>
                                <th>外显名称</th>
                                <th>外显号码</th>
                                <th>出局名称</th>
                                <th>出局号码</th>
                                <th>创建时间</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($val->username); ?></td>
                                    <td><?php echo e($val->password); ?></td>
                                    <td><?php echo e($val->effective_caller_id_name); ?></td>
                                    <td><?php echo e($val->effective_caller_id_number); ?></td>
                                    <td><?php echo e($val->outbound_caller_id_name); ?></td>
                                    <td><?php echo e($val->outbound_caller_id_number); ?></td>
                                    <td><?php echo e($val->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="7">无数据</td></tr>
                            </tbody>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        layui.use(['layer','table','form','element'],function () {
            var $ = layui.jquery;
            var layer = layui.layer;
            var form = layui.form;
            var table = layui.table;
            var element = layui.element;

            $("#checkAll").click(function () {
                var pop = $(this).prop('checked');
                $(".checkItem").prop('checked',pop);
            })

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/merchant/show.blade.php ENDPATH**/ ?>