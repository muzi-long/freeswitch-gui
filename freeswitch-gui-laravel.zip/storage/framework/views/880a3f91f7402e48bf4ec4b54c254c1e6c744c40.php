<?php $__env->startSection('content'); ?>
    <h2>无权限访问</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/errors/403.blade.php ENDPATH**/ ?>