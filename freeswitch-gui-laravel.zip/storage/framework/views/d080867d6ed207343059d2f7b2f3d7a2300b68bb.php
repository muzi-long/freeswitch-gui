<?php $__env->startSection('content'); ?>
    <div class="layui-row layui-col-space15">
            <div class="layui-col-md12">
                <div class="layui-row layui-col-space15">
                    <div class="layui-col-md4">
                        <div class="layui-card">
                            <div class="layui-card-header">快捷方式</div>
                            <div class="layui-card-body">
                                <div class="layui-carousel layadmin-carousel layadmin-shortcut">
                                    <div >
                                        <ul class="layui-row layui-col-space10">
                                            <li class="layui-col-xs3">
                                                <a lay-href="<?php echo e(route('admin.sip')); ?>">
                                                    <i class="layui-icon layui-icon-console"></i>
                                                    <cite>分机管理</cite>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs3">
                                                <a lay-href="<?php echo e(route('admin.gateway')); ?>">
                                                    <i class="layui-icon layui-icon-chart"></i>
                                                    <cite>网关管理</cite>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs3">
                                                <a lay-href="<?php echo e(route('admin.merchant')); ?>">
                                                    <i class="layui-icon layui-icon-template-1"></i>
                                                    <cite>商户管理</cite>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs3">
                                                <a lay-href="<?php echo e(route('admin.member')); ?>">
                                                    <i class="layui-icon layui-icon-chat"></i>
                                                    <cite>员工管理</cite>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs3">
                                                <a lay-href="<?php echo e(route('admin.extension')); ?>">
                                                    <i class="layui-icon layui-icon-find-fill"></i>
                                                    <cite>拨号计划</cite>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs3">
                                                <a lay-href="<?php echo e(route('admin.user')); ?>">
                                                    <i class="layui-icon layui-icon-survey"></i>
                                                    <cite>用户管理</cite>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs3">
                                                <a lay-href="<?php echo e(route('admin.role')); ?>">
                                                    <i class="layui-icon layui-icon-user"></i>
                                                    <cite>角色管理</cite>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs3">
                                                <a lay-href="<?php echo e(route('admin.user.changeMyPasswordForm')); ?>">
                                                    <i class="layui-icon layui-icon-set"></i>
                                                    <cite>修改密码</cite>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="layui-col-md4">
                        <div class="layui-card">
                            <div class="layui-card-header">服务配置</div>
                            <div class="layui-card-body">
                                <div class="layui-carousel layadmin-carousel layadmin-backlog">
                                    <div>
                                        <ul class="layui-row layui-col-space10">
                                            <li class="layui-col-xs6">
                                                <a  class="layadmin-backlog-body">
                                                    <h3>商户数量</h3>
                                                    <p><cite><?php echo e($merchantNum); ?></cite></p>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs6">
                                                <a  class="layadmin-backlog-body">
                                                    <h3>员工数量</h3>
                                                    <p><cite><?php echo e($memberNum); ?></cite></p>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs6">
                                                <a  class="layadmin-backlog-body">
                                                    <h3>网关数量</h3>
                                                    <p><cite><?php echo e($gatewayNum); ?></cite></p>
                                                </a>
                                            </li>
                                            <li class="layui-col-xs6">
                                                <a  class="layadmin-backlog-body">
                                                    <h3>分机数量</h3>
                                                    <p><cite><?php echo e($sipNum); ?></cite></p>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="layui-col-md4">
                        <div class="layui-card">
                            <div class="layui-card-header">版本信息</div>
                            <div class="layui-card-body layui-text">
                                <table class="layui-table">
                                    <colgroup>
                                        <col width="100"><col>
                                    </colgroup>
                                    <tbody>
                                    <tr>
                                        <td>当前版本</td>
                                        <td>v2.0.0</td>
                                    </tr>
                                    <tr>
                                        <td>基于系统</td>
                                        <td>freeswitch1.8+laravel6.*+LayuiAdmin</td>
                                    </tr>
                                    <tr>
                                        <td>主要特色</td>
                                        <td>外呼功能 / 批量呼出 / 通话记录 / 客户CRM</td>
                                    </tr>
                                    <tr>
                                        <td>获取渠道</td>
                                        <td style="padding-bottom: 0;">
                                            <div class="layui-btn-container">
                                                <a href="javascript:;" onclick="layer.tips('请联系作者', this, {tips: 1});" class="layui-btn layui-btn-danger">获取授权</a>
                                                <a href="/uploads/client.zip" class="layui-btn">客户端下载</a>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="layui-col-md12">
                        <div class="layui-card">
                            <div class="layui-card-header">呼叫统计</div>
                            <div class="layui-card-body layui-text">
                                <table class="layui-table">
                                    <colgroup>
                                        <col align="center"><col>
                                    </colgroup>
                                    <thead>
                                    <tr>
                                        <td rowspan="2"><b>商户</b></td>
                                        <td rowspan="2"><b>分机</b></td>
                                        <td align="center" colspan="3"><b>当日</b></td>
                                        <td align="center" colspan="3"><b>本周</b></td>
                                        <td align="center" colspan="3"><b>本月</b></td>
                                    </tr>
                                    <tr>
                                        <td align="center">呼出</td>
                                        <td align="center">接通</td>
                                        <td align="center">接通率</td>
                                        <td align="center">呼出</td>
                                        <td align="center">接通</td>
                                        <td align="center">接通率</td>
                                        <td align="center">呼出</td>
                                        <td align="center">接通</td>
                                        <td align="center">接通率</td>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php $__currentLoopData = $data->sips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php if($loop->first): ?>
                                            <td rowspan="<?php echo e(count($data->sips)); ?>"><?php echo e($data->info->company_name); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($sip->username); ?></td>
                                            <td align="center" style="color: red"><?php echo e($sip->todayCalls); ?></td>
                                            <td align="center" style="color: green"><?php echo e($sip->todaySuccessCalls); ?></td>
                                            <td align="center" style="color: #0000FF"><?php echo e($sip->todayRateCalls); ?>%</td>
                                            <td align="center" style="color: red"><?php echo e($sip->weekCalls); ?></td>
                                            <td align="center" style="color: green"><?php echo e($sip->weekSuccessCalls); ?></td>
                                            <td align="center" style="color: #0000FF"><?php echo e($sip->weekRateCalls); ?>%</td>
                                            <td align="center" style="color: red"><?php echo e($sip->monthCalls); ?></td>
                                            <td align="center" style="color: green"><?php echo e($sip->monthSuccessCalls); ?></td>
                                            <td align="center" style="color: #0000FF"><?php echo e($sip->monthRateCalls); ?>%</td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><td colspan="11" align="center">暂无数据</td></tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        layui.use(['index', 'sample']);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/index/index.blade.php ENDPATH**/ ?>