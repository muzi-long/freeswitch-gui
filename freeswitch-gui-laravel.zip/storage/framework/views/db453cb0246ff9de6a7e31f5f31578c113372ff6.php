<script>
    layui.use(['layer','table','form'],function () {
        var $ = layui.jquery;
        var layer = layui.layer;
        var form = layui.form;
        var table = layui.table;

        $(".tts-btn").click(function () {
            layer.open({
                type:2,
                title:'语音在线合成',
                area:['80%','80%'],
                shadeClose:true,
                content:"<?php echo e(route('admin.audio')); ?>"
            })
        })

    })
</script><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/ivr/_js.blade.php ENDPATH**/ ?>