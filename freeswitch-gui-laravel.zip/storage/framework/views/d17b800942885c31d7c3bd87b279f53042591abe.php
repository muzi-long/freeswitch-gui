<?php $__env->startSection('content'); ?>
    <style>
        .layui-form-checkbox span{width: 100px}
    </style>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>分配网关</h2>
        </div>
        <div class="layui-card-body">
            <form class="layui-form" action="<?php echo e(route('admin.merchant.assignGateway',['id'=>$merchant->id])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('put')); ?>

                <div class="layui-form-item">
                    <label for="" class="layui-form-label">帐号</label>
                    <div class="layui-form-mid layui-word-aux"><?php echo e($merchant->username); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">公司名称</label>
                    <div class="layui-form-mid layui-word-aux"><?php echo e($merchant->company_name); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">选择网关</label>
                    <div class="layui-input-block" style="width: 600px" >
                        <table class="layui-table" lay-size="sm">
                            <thead>
                            <tr>
                                <th width="20"><input type="checkbox" lay-ignore lay-skin="primary" id="checkAll" ></th>
                                <th>网关名称</th>
                                <th>网关帐号</th>
                                <th>注册地址</th>
                                <th width="100">费率（元/分钟）</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><input type="checkbox" class="checkItem" lay-ignore name="gateways[<?php echo e($loop->index); ?>][id]" value="<?php echo e($gateway->id); ?>" <?php if($merchant->gateways->contains($gateway)): ?> checked <?php endif; ?> ></td>
                                <td><?php echo e($gateway->name); ?></td>
                                <td><?php echo e($gateway->username); ?></td>
                                <td><?php echo e($gateway->realm); ?></td>
                                <td><input type="text" name="gateways[<?php echo e($loop->index); ?>][rate]" value="<?php echo e($gateway->rate); ?>" class="layui-input" lay-verify="required|number" style="height:26px;line-height: 26px"></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5">没有可分配的网关，请联系管理员</td></tr>
                            </tbody>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button type="submit" class="layui-btn" lay-submit="" lay-filter="formDemo">确 认</button>
                        <a class="layui-btn" href="<?php echo e(route('admin.merchant')); ?>" >返 回</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        layui.use(['layer','table','form'],function () {
            var layer = layui.layer;
            var form = layui.form;
            var table = layui.table;
            
            $("#checkAll").click(function () {
                var pop = $(this).prop('checked');
                $(".checkItem").prop('checked',pop);
            })
            
        })
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/merchant/gateway.blade.php ENDPATH**/ ?>