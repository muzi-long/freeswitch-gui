<script>
    layui.config({
        base: '/static/admin/layuiadmin/modules/'
    }).extend({
        selectN: 'select-ext/selectN'
    }).use(['layer','table','form','selectN'],function () {
        var layer = layui.layer;
        var form = layui.form;
        var table = layui.table;
        var selectN = layui.selectN;

        var mg_selected = [];
        <?php if(isset($model)): ?>
            mg_selected = ['<?php echo e($model->merchant_id); ?>','<?php echo e($model->gateway_id); ?>'];
        <?php endif; ?>

        var merchant_gateway = selectN({
            //元素容器【必填】
            elem: '#merchant_gateway'
            ,name:'merchant_gateway'
            ,verify:'required'
            ,selected:mg_selected
            //候选数据【必填】
            ,data: "<?php echo e(route('merchant-gateway')); ?>"
            ,field:{
                idName: 'id',
                titleName: 'name',
                childName: 'gateways'
            }
        });


    })
</script><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/sip/_js.blade.php ENDPATH**/ ?>