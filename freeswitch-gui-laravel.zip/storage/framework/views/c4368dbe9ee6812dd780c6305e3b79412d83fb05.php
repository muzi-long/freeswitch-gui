<script>
    layui.use(['layer','table','form','laydate'],function () {
        var layer = layui.layer;
        var form = layui.form;
        var table = layui.table;
        var laydate = layui.laydate;

        laydate.render({elem:'#date_start',type:'date'});
        laydate.render({elem:'#date_end',type:'date'});
        laydate.render({elem:'#time_start',type:'time'});
        laydate.render({elem:'#time_end',type:'time'});

    })
</script><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/task/_js.blade.php ENDPATH**/ ?>