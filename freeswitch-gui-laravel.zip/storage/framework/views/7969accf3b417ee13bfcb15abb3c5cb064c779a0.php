<?php echo e(csrf_field()); ?>

<div class="layui-form-item">
    <label for="" class="layui-form-label">商户</label>
    <div class="layui-input-inline">
        <select name="merchant_id" lay-verify="required">
            <option value=""></option>
            <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($m->id); ?>" <?php if(isset($model)&&$model->merchant_id==$m->id): ?> selected <?php endif; ?> ><?php echo e($m->username); ?>（<?php echo e($m->info->company_name); ?>）</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">帐号</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="username" lay-verify="required" value="<?php echo e($model->username??old('username')); ?>" placeholder="商家帐号">
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">密码</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="password" name="password" <?php if(!isset($model)): ?> lay-verify="required" <?php endif; ?> value="<?php echo e(old('password')); ?>" placeholder="商家密码">
    </div>
    <div class="layui-word-aux layui-form-mid">不修改则留空</div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">联系人</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="contact_name" lay-verify="required" value="<?php echo e($model->contact_name??old('contact_name')); ?>" placeholder="联系人">
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">联系电话</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="contact_phone" lay-verify="required" value="<?php echo e($model->contact_phone??old('contact_phone')); ?>" placeholder="联系电话">
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">状态</label>
    <div class="layui-input-inline">
        <select name="status" lay-verify="required">
            <option value="">请选择</option>
            <?php $__currentLoopData = config('freeswitch.merchant_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k); ?>" <?php if(isset($model)&&$model->status==$k): ?> selected <?php endif; ?> ><?php echo e($v); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="layui-form-item">
    <div class="layui-input-block">
        <button type="submit" class="layui-btn" lay-submit="" >确 认</button>
        <a href="<?php echo e(route('admin.member')); ?>" class="layui-btn" >返 回</a>
    </div>
</div><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/member/_form.blade.php ENDPATH**/ ?>