<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>更新网关</h2>
        </div>
        <div class="layui-card-body">
            <form action="<?php echo e(route('admin.gateway.update',['id'=>$model->id])); ?>" method="post" class="layui-form">
                <?php echo e(method_field('put')); ?>

                <?php echo $__env->make('admin.gateway._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/gateway/edit.blade.php ENDPATH**/ ?>