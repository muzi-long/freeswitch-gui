<?php echo e(csrf_field()); ?>

<div class="layui-form-item">
    <label for="" class="layui-form-label">名称</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="name" lay-verify="required" value="<?php echo e($model->name??old('name')); ?>" placeholder="请输入名称">
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">排序</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="number" name="sort" lay-verify="required" value="<?php echo e($model->sort??10); ?>" placeholder="序号">
    </div>
</div>
<div class="layui-form-item">
    <div class="layui-input-block">
        <button type="submit" class="layui-btn" lay-submit lay-filter="*" >确 认</button>
        <a href="<?php echo e(route('home.node')); ?>" class="layui-btn" >返 回</a>
    </div>
</div><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/home/node/_form.blade.php ENDPATH**/ ?>