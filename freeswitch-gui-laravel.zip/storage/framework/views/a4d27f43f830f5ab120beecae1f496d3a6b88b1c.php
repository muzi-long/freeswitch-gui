<?php echo e(csrf_field()); ?>


<div class="layui-form-item">
    <label for="" class="layui-form-label">父级</label>
    <div class="layui-input-inline">
        <select name="parent_id">
            <option value="0">顶级权限</option>
            <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($p1->id); ?>" <?php echo e(isset($permission->id) && $p1->id == $permission->parent_id ? 'selected' : ''); ?> ><?php echo e($p1->display_name); ?></option>
                <?php if($p1->childs->isNotEmpty()): ?>
                    <?php $__currentLoopData = $p1->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p2->id); ?>" <?php echo e(isset($permission->id) && $p2->id == $permission->parent_id ? 'selected' : ''); ?> >&nbsp;&nbsp;&nbsp;┗━━<?php echo e($p2->display_name); ?></option>
                        <?php if($p2->childs->isNotEmpty()): ?>
                            <?php $__currentLoopData = $p2->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p3->id); ?>" <?php echo e(isset($permission->id) && $p3->id == $permission->parent_id ? 'selected' : ''); ?> >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;┗━━<?php echo e($p3->display_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>
</div>

<div class="layui-form-item">
    <label for="" class="layui-form-label">名称</label>
    <div class="layui-input-inline">
        <input type="text" name="name" value="<?php echo e($permission->name??old('name')); ?>" lay-verify="required" class="layui-input" placeholder="如：system.index">
    </div>
</div>

<div class="layui-form-item">
    <label for="" class="layui-form-label">显示名称</label>
    <div class="layui-input-inline">
        <input type="text" name="display_name" value="<?php echo e($permission->display_name??old('display_name')); ?>" lay-verify="required" class="layui-input" placeholder="如：系统管理">
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">路由</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="route" value="<?php echo e($permission->route??old('route')); ?>" placeholder="如：admin.member" >
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">链接</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="url" value="<?php echo e($permission->url??old('url')); ?>" placeholder="如：/admin/xxx" >
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">类型</label>
    <div class="layui-input-inline">
        <input type="radio" name="type" value="1" title="按钮" <?php if(isset($permission) && $permission->type==1): ?> checked <?php endif; ?> >
        <input type="radio" name="type" value="2" title="菜单" <?php if(!isset($permission) || (isset($permission) && $permission->type==2)): ?> checked <?php endif; ?>>
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">可见性</label>
    <div class="layui-input-inline">
        <input type="radio" name="visiable" value="1" title="显示" <?php if(isset($permission) && $permission->visiable==1): ?> checked <?php endif; ?> >
        <input type="radio" name="visiable" value="2" title="隐藏" <?php if(!isset($permission) || (isset($permission) && $permission->visiable==2)): ?> checked <?php endif; ?>>
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">图标</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="hidden" name="icon" value="<?php echo e($permission->icon??''); ?>" >
    </div>
    <div class="layui-form-mid layui-word-aux" id="icon_box">
        <i class="layui-icon <?php echo e($permission->icon??''); ?>"></i>
    </div>
    <div class="layui-form-mid layui-word-aux">
        <button type="button" class="layui-btn layui-btn-xs" onclick="showIconsBox()">选择图标</button>
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">排序</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="number" name="sort" value="<?php echo e($permission->sort??0); ?>" placeholder="" >
    </div>
</div>
<div class="layui-form-item">
    <div class="layui-input-block">
        <button type="submit" class="layui-btn" lay-submit="" >确 认</button>
        <a href="<?php echo e(route('admin.permission')); ?>" class="layui-btn"  >返 回</a>
    </div>
</div>

<?php /**PATH D:\wnmp\www\my_laravel\resources\views/admin/permission/_from.blade.php ENDPATH**/ ?>