<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <div class="layui-btn-group">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('system.configuration.create')): ?>
                    <a class="layui-btn layui-btn-sm" href="<?php echo e(route('admin.configuration.create')); ?>">添 加</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="layui-card-body">
            <div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
                <ul class="layui-tab-title">
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li <?php if($loop->index==0): ?> class="layui-this" <?php endif; ?> ><?php echo e($group->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="layui-tab-content">
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="layui-tab-item <?php if($loop->index==0): ?> layui-show <?php endif; ?>">
                            <form class="layui-form">
                                <?php $__currentLoopData = $group->configurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $configuration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="layui-form-item">
                                        <label for="" class="layui-form-label" style="width: 120px"><?php echo e($configuration->label); ?></label>
                                        <div class="layui-input-inline" style="min-width: 600px">
                                            <?php switch($configuration->type):
                                                case ('input'): ?>
                                                    <input type="input" class="layui-input" name="<?php echo e($configuration->key); ?>" value="<?php echo e($configuration->val); ?>">
                                                    <?php break; ?>
                                                <?php case ('textarea'): ?>
                                                    <textarea name="<?php echo e($configuration->key); ?>" class="layui-textarea"><?php echo e($configuration->val); ?></textarea>
                                                    <?php break; ?>
                                                <?php case ('select'): ?>
                                                    <select name="<?php echo e($configuration->key); ?>">
                                                        <?php if($configuration->content): ?>
                                                            <?php $__currentLoopData = explode("|",$configuration->content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $key = \Illuminate\Support\Str::before($v,':');
                                                                    $val = \Illuminate\Support\Str::after($v,':');
                                                                ?>
                                                                <option value="<?php echo e($key); ?>" <?php if($key==$configuration->val): ?> selected <?php endif; ?> ><?php echo e($val); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                    <?php break; ?>
                                                <?php case ('radio'): ?>
                                                    <?php if($configuration->content): ?>
                                                        <?php $__currentLoopData = explode("|",$configuration->content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $key = \Illuminate\Support\Str::before($v,':');
                                                                $val = \Illuminate\Support\Str::after($v,':');
                                                            ?>
                                                            <input type="radio" name="<?php echo e($configuration->key); ?>" value="<?php echo e($key); ?>" <?php if($key==$configuration->val): ?> checked <?php endif; ?> title="<?php echo e($val); ?>">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    <?php break; ?>
                                                <?php case ('image'): ?>
                                                    <div class="layui-upload">
                                                        <button type="button" class="layui-btn layui-btn-sm uploadPic"><i class="layui-icon">&#xe67c;</i>图片上传</button>
                                                        <div class="layui-upload-list" >
                                                            <ul class="layui-upload-box layui-clear">
                                                                <?php if($configuration->val): ?>
                                                                    <li><img src="<?php echo e($configuration->val); ?>" /><p>上传成功</p></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                            <input type="hidden" class="layui-upload-input" name="<?php echo e($configuration->key); ?>" value="<?php echo e($configuration->val); ?>">
                                                        </div>
                                                    </div>
                                                    <?php break; ?>
                                                <?php default: ?>
                                                    <?php break; ?>
                                            <?php endswitch; ?>
                                        </div>
                                        <div class="layui-form-mid layui-word-aux"><?php echo e($configuration->tips); ?></div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="layui-form-item">
                                        <div class="layui-input-block">
                                            <button type="submit" class="layui-btn" lay-submit lay-filter="config_group">确 认</button>
                                        </div>
                                    </div>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('system.configuration')): ?>
        <script>
            layui.use(['layer', 'table', 'form','upload','element'], function () {
                var $ = layui.jquery;
                var layer = layui.layer;
                var form = layui.form;
                var table = layui.table;
                var upload = layui.upload;

                //图片
                $(".uploadPic").each(function (index,elem) {
                    upload.render({
                        elem: $(elem)
                        ,url: '<?php echo e(route("api.upload")); ?>'
                        ,multiple: false
                        ,data:{"_token":"<?php echo e(csrf_token()); ?>"}
                        ,done: function(res){
                            //如果上传失败
                            if(res.code == 0){
                                layer.msg(res.msg,{icon:1},function () {
                                    $(elem).parent('.layui-upload').find('.layui-upload-box').html('<li><img src="'+res.url+'" /><p>上传成功</p></li>');
                                    $(elem).parent('.layui-upload').find('.layui-upload-input').val(res.url);
                                })
                            }else {
                                layer.msg(res.msg,{icon:2})
                            }
                        }
                    });
                })

                //提交
                form.on('submit(config_group)',function (data) {
                    var parm = data.field;
                    parm['_method'] = 'put';
                    var load = layer.load();
                    $.post("<?php echo e(route('admin.configuration.update')); ?>",data.field,function (res) {
                        layer.close(load);
                        if (res.code==0){
                            layer.msg(res.msg,{icon:1})
                        }else {
                            layer.msg(res.msg,{icon:2});
                        }
                    });
                    return false;
                });
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/configuration/index.blade.php ENDPATH**/ ?>