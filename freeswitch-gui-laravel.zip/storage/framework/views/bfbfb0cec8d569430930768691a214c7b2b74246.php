<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>项目详情</h2>
            <?php echo $__env->make('home.project._btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="layui-card-body">
            <div class="layui-row">
                <div class="layui-col-xs5">
                    <div class="layui-card">
                        <div class="layui-card-header"><b>客户信息</b></div>
                        <div class="layui-card-body">
                            <table class="layui-table" lay-skin="nob">
                                <tbody>
                                <tr>
                                    <td width="80" align="right">客户姓名：</td>
                                    <td><?php echo e($model->name); ?></td>
                                    <td width="80" align="right">跟进时间：</td>
                                    <td><?php echo e($model->follow_at); ?></td>
                                </tr>
                                <tr>
                                    <td width="80" align="right">联系电话：</td>
                                    <td><?php echo e($model->phone); ?></td>
                                    <td width="80" align="right">跟进人：</td>
                                    <td><?php echo e($model->followMerchant->contact_name); ?></td>
                                </tr>
                                <tr>
                                    <td width="80" align="right">公司名称：</td>
                                    <td><?php echo e($model->company_name); ?></td>
                                    <td width="80" align="right">当前节点：</td>
                                    <td><?php echo e($model->node->name); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="layui-col-xs5 layui-col-lg-offset2">
                    <div class="layui-card">
                        <div class="layui-card-header"><b>扩展信息</b></div>
                        <div class="layui-card-body">
                            <table class="layui-table" lay-skin="nob">
                                <tbody>
                                <?php $__currentLoopData = $model->designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="80" align="right"><?php echo e($d->field_label); ?>：</td>
                                    <td>
                                        <?php switch($d->field_type):
                                            case ('select'): ?>
                                                <?php if($d->field_option&&strpos($d->field_option,'|')): ?>
                                                    <?php $__currentLoopData = explode("|",$d->field_option); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $key = \Illuminate\Support\Str::before($v,':');
                                                            $val = \Illuminate\Support\Str::after($v,':');
                                                        ?>
                                                        <?php if($key==$d->pivot->data): ?>
                                                            <?php echo e($val); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <?php break; ?>
                                            <?php case ('radio'): ?>
                                                <?php if($d->field_option&&strpos($d->field_option,'|')): ?>
                                                    <?php $__currentLoopData = explode("|",$d->field_option); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $key = \Illuminate\Support\Str::before($v,':');
                                                            $val = \Illuminate\Support\Str::after($v,':');
                                                        ?>
                                                        <?php if($key==$d->pivot->data): ?>
                                                            <?php echo e($val); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <?php break; ?>
                                            <?php case ('checkbox'): ?>
                                                <?php if($d->field_option&&strpos($d->field_option,'|')): ?>
                                                    <?php $__currentLoopData = explode("|",$d->field_option); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $key = \Illuminate\Support\Str::before($v,':');
                                                            $val = \Illuminate\Support\Str::after($v,':');
                                                            $fieldValue = [];
                                                            if ($d->pivot->data&&strpos($d->pivot->data,',')){
                                                                $fieldValue = explode(",",$d->pivot->data);
                                                            }
                                                        ?>
                                                        <?php if(in_array($key,$fieldValue) || $key==$d->pivot->data ): ?>
                                                            <?php echo e($val); ?>&nbsp;&nbsp;
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <?php break; ?>
                                            <?php case ('image'): ?>
                                                <?php if($d->pivot->data): ?>
                                                    <a href="<?php echo e($d->pivot->data); ?>" target="_blank"><img src="<?php echo e($d->pivot->data); ?>" alt="" width="80" height="40"></a>
                                                <?php endif; ?>
                                                <?php break; ?>
                                            <?php default: ?>
                                                <?php echo e($d->pivot->data); ?>

                                                <?php break; ?>
                                        <?php endswitch; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="layui-row layui-col-space30">
                <div class="layui-col-xs6">
                    <div class="layui-card">
                        <div class="layui-card-header"><b>节点进度</b></div>
                        <div class="layui-card-body">
                            <table id="dataTableNode" lay-filter="dataTableNode"></table>
                        </div>
                    </div>
                </div>
                <div class="layui-col-xs6">
                    <div class="layui-card">
                        <div class="layui-card-header"><b>备注进度</b></div>
                        <div class="layui-card-body">
                            <table id="dataTableRemark" lay-filter="dataTableRemark"></table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('home.project._js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/home/project/show.blade.php ENDPATH**/ ?>