<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>添加配置</h2>
        </div>
        <div class="layui-card-body">
            <form class="layui-form" action="<?php echo e(route('admin.configuration.store')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="layui-form-item">
                    <label for="" class="layui-form-label">配置组</label>
                    <div class="layui-input-inline">
                        <select name="group_id" lay-verify="required">
                            <option value=""></option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">类型</label>
                    <div class="layui-input-inline">
                        <select name="type" >
                            <option value="input">输入框</option>
                            <option value="textarea">文本域</option>
                            <option value="radio">单选</option>
                            <option value="select">下拉</option>
                            <option value="image">图片</option>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">配置名称</label>
                    <div class="layui-input-inline">
                        <input type="text" name="label" value="<?php echo e(old('label')); ?>" lay-verify="required" placeholder="请输入名称" class="layui-input" >
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">配置字段</label>
                    <div class="layui-input-inline">
                        <input type="text" name="key" value="<?php echo e(old('key')); ?>" lay-verify="required" placeholder="请输入,如name" class="layui-input" >
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">配置值</label>
                    <div class="layui-input-inline">
                        <input type="text" name="val" value="<?php echo e(old('val')); ?>" lay-verify="required" placeholder="请输入" class="layui-input" >
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">输入提示</label>
                    <div class="layui-input-inline">
                        <input type="text" name="tips" value="<?php echo e(old('tips')); ?>" placeholder="请输入" class="layui-input" >
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">排序</label>
                    <div class="layui-input-inline">
                        <input type="number" name="sort" value="<?php echo e(old('sort',10)); ?>" placeholder="请输入" class="layui-input" >
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button type="submit" class="layui-btn" lay-submit="" lay-filter="formDemo">确 认</button>
                        <a  class="layui-btn" href="<?php echo e(route('admin.configuration')); ?>" >返 回</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        layui.use(['element','form'],function () {

        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/configuration/create.blade.php ENDPATH**/ ?>