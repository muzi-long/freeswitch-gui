
<div class="layui-form-item">
    <div class="layui-input-block">
        <button type="submit" class="layui-btn" lay-submit lay-filter="*" >确 认</button>
        <a href="<?php echo e(route('home.project')); ?>" class="layui-btn" >返 回</a>
    </div>
</div><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/home/project/_form.blade.php ENDPATH**/ ?>