<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>添加项目</h2>
        </div>
        <div class="layui-card-body">
            <form action="<?php echo e(route('home.project.store')); ?>" method="post" class="layui-form">
                <?php echo e(csrf_field()); ?>

                <div class="layui-form-item">
                    <label for="" class="layui-form-label">公司名称</label>
                    <div class="layui-input-inline" style="width: 400px">
                        <input class="layui-input" type="text" name="company_name" lay-verify="required" value="<?php echo e($model->company_name??old('company_name')); ?>" placeholder="请输入公司名称">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">姓名</label>
                    <div class="layui-input-inline" style="width: 400px">
                        <input class="layui-input" type="text" name="name" lay-verify="required" value="<?php echo e($model->name??old('name')); ?>" placeholder="请输入名称">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">电话</label>
                    <div class="layui-input-inline" style="width: 400px">
                        <input class="layui-input" type="number" name="phone" lay-verify="required|phone" value="<?php echo e($model->phone??old('phone')); ?>" placeholder="请输入联系电话">
                    </div>
                </div>
                <?php $__currentLoopData = $designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="layui-form-item">
                        <label for="" class="layui-form-label"><?php echo e($d->field_label); ?></label>
                        <div class="layui-input-inline" style="width: 400px">
                            <?php switch($d->field_type):
                                case ('input'): ?>
                                <input type="input" class="layui-input" name="<?php echo e($d->field_key); ?>" value="<?php echo e($d->field_value); ?>" <?php if($d->required==1): ?> lay-verify="required" <?php endif; ?> placeholder="<?php echo e($d->field_tips); ?>" >
                                <?php break; ?>
                                <?php case ('textarea'): ?>
                                <textarea name="<?php echo e($d->field_key); ?>" class="layui-textarea" <?php if($d->required==1): ?> lay-verify="required" <?php endif; ?> placeholder="<?php echo e($d->field_tips); ?>"><?php echo e($d->field_value); ?></textarea>
                                <?php break; ?>
                                <?php case ('select'): ?>
                                <select name="<?php echo e($d->field_key); ?>" <?php if($d->required==1): ?> lay-verify="required" <?php endif; ?>>
                                    <?php if($d->field_option&&strpos($d->field_option,'|')): ?>
                                        <?php $__currentLoopData = explode("|",$d->field_option); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $key = \Illuminate\Support\Str::before($v,':');
                                                $val = \Illuminate\Support\Str::after($v,':');
                                            ?>
                                            <option value="<?php echo e($key); ?>" <?php if($key==$d->field_value): ?> selected <?php endif; ?> ><?php echo e($val); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <?php break; ?>
                                <?php case ('radio'): ?>
                                <?php if($d->field_option&&strpos($d->field_option,'|')): ?>
                                    <?php $__currentLoopData = explode("|",$d->field_option); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $key = \Illuminate\Support\Str::before($v,':');
                                            $val = \Illuminate\Support\Str::after($v,':');
                                        ?>
                                        <input type="radio" name="<?php echo e($d->field_key); ?>" value="<?php echo e($key); ?>" <?php if($key==$d->field_value): ?> checked <?php endif; ?> title="<?php echo e($val); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php break; ?>
                                <?php case ('checkbox'): ?>
                                <?php if($d->field_option&&strpos($d->field_option,'|')): ?>
                                    <?php $__currentLoopData = explode("|",$d->field_option); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $key = \Illuminate\Support\Str::before($v,':');
                                            $val = \Illuminate\Support\Str::after($v,':');
                                            $fieldValue = [];
                                            if ($d->field_value&&strpos($d->field_value,',')){
                                                $fieldValue = explode(",",$d->field_value);
                                            }
                                        ?>
                                        <input type="checkbox" name="<?php echo e($d->field_key); ?>[]" value="<?php echo e($key); ?>" <?php if(in_array($key,$fieldValue) || $key==$d->field_value ): ?> checked <?php endif; ?> title="<?php echo e($val); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php break; ?>
                                <?php case ('image'): ?>
                                <div class="layui-upload">
                                    <button type="button" class="layui-btn layui-btn-sm uploadPic"><i class="layui-icon">&#xe67c;</i>图片上传</button>
                                    <div class="layui-upload-list" >
                                        <ul class="layui-upload-box layui-clear">
                                        </ul>
                                        <input type="hidden" class="layui-upload-input" name="<?php echo e($d->field_key); ?>" value="<?php echo e($d->field_value); ?>">
                                    </div>
                                </div>
                                <?php break; ?>
                                <?php default: ?>
                                <?php break; ?>
                            <?php endswitch; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('home.project._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('home.project._js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/home/project/create.blade.php ENDPATH**/ ?>