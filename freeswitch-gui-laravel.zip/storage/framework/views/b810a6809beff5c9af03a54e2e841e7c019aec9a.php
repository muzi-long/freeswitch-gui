<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>分机统计</h2>
        </div>
        <div class="layui-card-body">
            <table class="layui-table">
                <colgroup>
                    <col align="center"><col>
                </colgroup>
                <thead>
                <tr>
                    <td rowspan="2"><b>员工</b></td>
                    <td rowspan="2"><b>分机</b></td>
                    <td align="center" colspan="3"><b>当日</b></td>
                    <td align="center" colspan="3"><b>本周</b></td>
                    <td align="center" colspan="3"><b>本月</b></td>
                </tr>
                <tr>
                    <td align="center">呼出</td>
                    <td align="center">接通</td>
                    <td align="center">接通率</td>
                    <td align="center">呼出</td>
                    <td align="center">接通</td>
                    <td align="center">接通率</td>
                    <td align="center">呼出</td>
                    <td align="center">接通</td>
                    <td align="center">接通率</td>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($sip->merchant->contact_name); ?></td>
                        <td><?php echo e($sip->username); ?></td>
                        <td align="center" style="color: red"><?php echo e($sip->todayCalls); ?></td>
                        <td align="center" style="color: green"><?php echo e($sip->todaySuccessCalls); ?></td>
                        <td align="center" style="color: #0000FF"><?php echo e($sip->todayRateCalls); ?>%</td>
                        <td align="center" style="color: red"><?php echo e($sip->weekCalls); ?></td>
                        <td align="center" style="color: green"><?php echo e($sip->weekSuccessCalls); ?></td>
                        <td align="center" style="color: #0000FF"><?php echo e($sip->weekRateCalls); ?>%</td>
                        <td align="center" style="color: red"><?php echo e($sip->monthCalls); ?></td>
                        <td align="center" style="color: green"><?php echo e($sip->monthSuccessCalls); ?></td>
                        <td align="center" style="color: #0000FF"><?php echo e($sip->monthRateCalls); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="10" align="center">暂无数据</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        layui.use(['layer','table','form','laydate'],function () {
            var $ = layui.jquery;
            var layer = layui.layer;
            var form = layui.form;
            var table = layui.table;
            var laydate = layui.laydate;

        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/home/sip/count.blade.php ENDPATH**/ ?>