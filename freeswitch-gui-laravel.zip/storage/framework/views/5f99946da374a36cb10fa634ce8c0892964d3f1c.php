<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>拨号计划详情</h2>
        </div>
        <div class="layui-card-body">
            <table class="layui-table" lay-skin="nob">
                <tr>
                    <?php
                    $tips1 = "名称：".$extension->display_name."<br/>标识符：".$extension->name."<br/>continue：".$extension->continue."<br/>类型：".$extension->context_name;
                    ?>
                    <td onmouseleave="layer.closeAll()" onmouseenter="layer.tips('<?php echo e($tips1); ?>', this, {tips: 2,time:0});" >
                        <span><?php echo e($extension->display_name); ?></span>
                    </td>
                    <td>
                        <?php if($extension->conditions->isNotEmpty()): ?>
                        <table class="layui-table" lay-skin="row">
                            <?php $__currentLoopData = $extension->conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php
                                $tips2 = "名称：".$condition->display_name."<br/>字段：".$condition->field."<br/>正则：".$condition->expression."<br/>break：".$condition->break;
                                ?>
                                <td onmouseleave="layer.closeAll()" onmouseenter="layer.tips('<?php echo e($tips2); ?>', this, {tips: 4,time:0});" >
                                    <span class="layui-badge layui-bg-cyan"><?php echo e($condition->sort); ?></span>
                                    <span><?php echo e($condition->display_name); ?></span>
                                </td>
                                <td>
                                    <?php if($condition->actions->isNotEmpty()): ?>
                                    <table class="layui-table" lay-skin="line">
                                        <?php $__currentLoopData = $condition->actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php
                                                $tips3 = "名称：".$action->display_name."<br/>应用：".$action->application_name."<br/>数据：".$action->data;
                                            ?>
                                            <td onmouseleave="layer.closeAll()" onmouseenter="layer.tips('<?php echo e($tips3); ?>', this, {tips: 4,time:0});">
                                                <span class="layui-badge layui-bg-cyan"><?php echo e($action->sort); ?></span>
                                                <span><?php echo e($action->display_name); ?></span>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/dialplan/extension/show.blade.php ENDPATH**/ ?>