<?php echo e(csrf_field()); ?>

<div class="layui-form-item">
    <label for="" class="layui-form-label">队列名称</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="display_name" lay-verify="required" value="<?php echo e($model->display_name??old('display_name')); ?>" placeholder="如：队列一">
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">队列号码</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" maxlength="4" name="name" lay-verify="required|number" value="<?php echo e($model->name??old('name')); ?>" placeholder="">
    </div>
    <div class="layui-form-mid layui-word-aux">请输入队列号码,8000-8999</div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">振铃策略</label>
    <div class="layui-input-inline">
        <select name="strategy" >
            <?php $__currentLoopData = config('freeswitch.strategy'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">超时时间</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" maxlength="4" name="max_wait_time" lay-verify="required|number" value="<?php echo e($model->max_wait_time??0); ?>" placeholder="">
    </div>
    <div class="layui-form-mid layui-word-aux">最大等待时间，默认0为禁用</div>
</div>
<div class="layui-form-item">
    <div class="layui-input-block">
        <button type="submit" class="layui-btn" lay-submit lay-filter="*" >确 认</button>
        <a href="<?php echo e(route('admin.queue')); ?>" class="layui-btn" >返 回</a>
    </div>
</div><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/queue/_form.blade.php ENDPATH**/ ?>