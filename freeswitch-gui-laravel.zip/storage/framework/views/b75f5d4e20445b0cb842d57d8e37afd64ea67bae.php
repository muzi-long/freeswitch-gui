<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>分配直接权限，直接权限与角色拥有的角色权限可叠加</h2>
        </div>
        <div class="layui-card-body">
            <form action="<?php echo e(route('admin.user.assignPermission',['id'=>$user->id])); ?>" method="post" class="layui-form">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('put')); ?>

                <div class="layui-form-item">
                    <label for="" class="layui-form-label">帐号</label>
                    <div class="layui-word-aux layui-form-mid"><?php echo e($user->username); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">昵称</label>
                    <div class="layui-word-aux layui-form-mid"><?php echo e($user->nickname); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">手机</label>
                    <div class="layui-word-aux layui-form-mid"><?php echo e($user->phone); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">邮箱</label>
                    <div class="layui-word-aux layui-form-mid"><?php echo e($user->email); ?></div>
                </div>
                <div class="layui-form-item">
                    <label for="" class="layui-form-label">权限</label>
                    <div class="layui-input-block">
                        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <dl class="cate-box">
                                <dt>
                                    <div class="cate-first"><input id="menu<?php echo e($p1->id); ?>" type="checkbox" name="permissions[]" value="<?php echo e($p1->id); ?>" title="<?php echo e($p1->display_name); ?>" lay-skin="primary" <?php echo e($p1->own??''); ?> ></div>
                                </dt>
                                <?php if($p1->childs->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $p1->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <dd>
                                            <div class="cate-second"><input id="menu<?php echo e($p1->id); ?>-<?php echo e($p2->id); ?>" type="checkbox" name="permissions[]" value="<?php echo e($p2->id); ?>" title="<?php echo e($p2->display_name); ?>" lay-skin="primary" <?php echo e($p2->own??''); ?>></div>
                                            <?php if($p2->childs->isNotEmpty()): ?>
                                                <div class="cate-third">
                                                    <?php $__currentLoopData = $p2->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <input type="checkbox" id="menu<?php echo e($p1->id); ?>-<?php echo e($p2->id); ?>-<?php echo e($p3->id); ?>" name="permissions[]" value="<?php echo e($p3->id); ?>" title="<?php echo e($p3->display_name); ?>" lay-skin="primary" <?php echo e($p3->own??''); ?>>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php endif; ?>
                                        </dd>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </dl>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div style="text-align: center;padding:20px 0;">
                                无数据
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label for="" class="layui-form-label"></label>
                    <div class="layui-input-block">
                        <button type="submit" class="layui-btn" lay-submit="" >确 认</button>
                        <a href="<?php echo e(route('admin.user')); ?>"  class="layui-btn" >返 回</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        layui.use(['layer','table','form'],function () {
            var $ = layui.jquery;
            var layer = layui.layer;
            var form = layui.form;
            var table = layui.table;
            form.on('checkbox', function (data) {
                var check = data.elem.checked;//是否选中
                var checkId = data.elem.id;//当前操作的选项框
                if (check) {
                    //选中
                    var ids = checkId.split("-");
                    if (ids.length == 3) {
                        //第三极菜单
                        //第三极菜单选中,则他的上级选中
                        $("#" + (ids[0] + '-' + ids[1])).prop("checked", true);
                        $("#" + (ids[0])).prop("checked", true);
                    } else if (ids.length == 2) {
                        //第二季菜单
                        $("#" + (ids[0])).prop("checked", true);
                        $("input[id*=" + ids[0] + '-' + ids[1] + "]").each(function (i, ele) {
                            $(ele).prop("checked", true);
                        });
                    } else {
                        //第一季菜单不需要做处理
                        $("input[id*=" + ids[0] + "-]").each(function (i, ele) {
                            $(ele).prop("checked", true);
                        });
                    }
                } else {
                    //取消选中
                    var ids = checkId.split("-");
                    if (ids.length == 2) {
                        //第二极菜单
                        $("input[id*=" + ids[0] + '-' + ids[1] + "]").each(function (i, ele) {
                            $(ele).prop("checked", false);
                        });
                    } else if (ids.length == 1) {
                        $("input[id*=" + ids[0] + "-]").each(function (i, ele) {
                            $(ele).prop("checked", false);
                        });
                    }
                }
                form.render();
            });
        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\my_laravel\resources\views/admin/user/permission.blade.php ENDPATH**/ ?>