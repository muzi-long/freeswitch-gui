
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="/static/admin/layuiadmin/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/layuiadmin/style/admin.css" media="all">
</head>
<body>

<div class="layui-fluid">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="/static/admin/layuiadmin/layui/layui.js"></script>
<script>
    function newTab(url,tit){
        if(top.layui.index){
            top.layui.index.openTabsPage(url,tit)
        }else{
            window.open(url)
        }
    }

    layui.config({
        base: '/static/admin/layuiadmin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['layer','jquery'],function () {
        var $ = layui.jquery;
        var layer = layui.layer;

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        //错误提示
        <?php if(count($errors)>0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                layer.msg("<?php echo e($error); ?>",{icon:2});
                <?php break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        //一次性正确信息提示
        <?php if(session('success')): ?>
            layer.msg("<?php echo e(session('success')); ?>",{icon:1});
        <?php endif; ?>

        //一次性错误信息提示
        <?php if(session('error')): ?>
        layer.msg("<?php echo e(session('error')); ?>",{icon:2});
        <?php endif; ?>

        //呼叫
        window.call = function (phone,exten="<?php echo e($exten); ?>") {
            layer.confirm('请确认已分配了分机并登录成功？',function(index) {
                layer.close(index);
                var load = layer.load();
                $.post("<?php echo e(route('api.dial')); ?>",{exten:exten,phone:phone},function(res) {
                    layer.close(load);
                    layer.msg(res.msg,{time:2000})
                });
            });
        }

    });
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>



<?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/home/base.blade.php ENDPATH**/ ?>