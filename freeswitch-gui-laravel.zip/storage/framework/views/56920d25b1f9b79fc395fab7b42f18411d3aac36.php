<?php $__env->startSection('content'); ?>
    <h1>
        <span class="layui-anim layui-anim-loop layui-anim-">4</span>
        <span class="layui-anim layui-anim-loop layui-anim-rotate">0</span>
        <span class="layui-anim layui-anim-loop layui-anim-">4</span>
    </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/errors/404.blade.php ENDPATH**/ ?>