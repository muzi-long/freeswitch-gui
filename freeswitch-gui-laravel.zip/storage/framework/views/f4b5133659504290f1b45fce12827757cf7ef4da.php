<?php $__env->startSection('content'); ?>
    <style>
        .layui-form-checkbox span{width: 500px;}
    </style>
    <div class="layui-card">
        <div class="layui-card-header layuiadmin-card-header-auto">
            <h2>队列【<?php echo e($queue->display_name); ?>】分配坐席</h2>
        </div>
        <div class="layui-card-body">
            <form class="layui-form" action="<?php echo e(route('admin.queue.assignAgent',['id'=>$queue->id])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('put')); ?>

                <div class="layui-form-item">
                    <label for="" class="layui-form-label">选择坐席</label>
                    <div class="layui-input-block">
                        <?php $__empty_1 = true; $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <input type="checkbox" name="agents[]" value="<?php echo e($agent->id); ?>" title="名称：<?php echo e($agent->display_name); ?>，号码：<?php echo e($agent->name); ?>，呼叫类型：<?php echo e($agent->originate_type_name); ?>， 呼叫号码：<?php echo e($agent->originate_number); ?>" <?php echo e($queue->agents->isNotEmpty()&&$queue->agents->contains($agent) ? 'checked' : ''); ?> >
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="layui-form-mid layui-word-aux">还没有坐席</div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button type="submit" class="layui-btn" lay-submit="" lay-filter="formDemo">确 认</button>
                        <a class="layui-btn" href="<?php echo e(route('admin.queue')); ?>" >返 回</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/admin/queue/agent.blade.php ENDPATH**/ ?>