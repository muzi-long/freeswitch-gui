<?php echo e(csrf_field()); ?>

<div class="layui-form-item">
    <label for="" class="layui-form-label">帐号</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" maxlength="16" name="username" lay-verify="required|username" value="<?php echo e($member->username??old('username')); ?>" placeholder="输入帐号">
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">联系人</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="contact_name" lay-verify="required" value="<?php echo e($member->contact_name??old('contact_name')); ?>" placeholder="输入联系人">
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">联系电话</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="text" name="contact_phone" lay-verify="required|phone" value="<?php echo e($member->contact_phone??old('contact_phone')); ?>" placeholder="如：13888888888" >
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">外呼号</label>
    <div class="layui-input-inline">
        <select name="sip_id" >
            <option value=""></option>
            <?php $__currentLoopData = $sips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($sip->id); ?>" <?php if($hasUsed->contains($sip->id)): ?> disabled <?php endif; ?>  <?php if(isset($member)&&$member->sip_id==$sip->id): ?> selected <?php endif; ?>  ><?php echo e($sip->username); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">密码</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="password" maxlength="16" name="password" value="" placeholder="输入密码" >
    </div>
    <?php if(isset($member)): ?><div class="layui-word-aux layui-form-mid">不修改则留空</div><?php endif; ?>
</div>
<div class="layui-form-item">
    <label for="" class="layui-form-label">确认密码</label>
    <div class="layui-input-inline">
        <input class="layui-input" type="password" maxlength="16" name="password_confirmation" value="" placeholder="输入密码" >
    </div>
    <?php if(isset($member)): ?><div class="layui-word-aux layui-form-mid">不修改则留空</div><?php endif; ?>
</div>
<div class="layui-form-item">
    <div class="layui-input-block">
        <button type="submit" class="layui-btn" lay-submit="" >确 认</button>
        <a href="<?php echo e(route('merchant.user')); ?>" class="layui-btn" >返 回</a>
    </div>
</div><?php /**PATH D:\wnmp\www\freeswitch-gui-laravel\resources\views/merchant/user/_form.blade.php ENDPATH**/ ?>