@extends('errors.base')

@section('content')
    <h2>页面不存在</h2>
@endsection
