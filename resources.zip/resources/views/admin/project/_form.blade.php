
<div class="layui-form-item">
    <div class="layui-input-block">
        <button type="button" class="layui-btn layui-btn-sm" lay-submit lay-filter="go" >确 认</button>
        <a href="{{route('admin.project')}}" class="layui-btn layui-btn-sm" >返 回</a>
    </div>
</div>