<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

class eslCdr extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'esl:cdr';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '从redis里取数据写入cdr';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $key = 'esl_cdr_key';
        while (true){
            $item = Redis::lPop($key);
            if ($item){
                try{
                    $data = json_decode($item,true);
                    if ($data['type']==1){ //通话记录
                        if ($data['leg_type']=='A'){
                            if (!$data['update_data']['src']) continue;
                            $model = DB::table('sip')
                                ->join('users','sip.id','=','users.sip_id')
                                ->where('sip.username',$data['update_data']['src'])
                                ->select(['users.id','users.department_id'])
                                ->first();
                            DB::table($data['table_name'])->updateOrInsert([
                                'uuid' => $data['uuid'],
                            ],array_merge($data['update_data'],[
                                'user_id' => $model->id??null,
                                'created_at' => date('Y-m-d H:i:s'),
                            ]));
                        }else{
                            DB::table($data['table_name'])->updateOrInsert([
                                'uuid' => $data['uuid'],
                            ],$data['update_data']);
                        }
                    }else{ //分段记录
                        DB::table($data['table_name'])->insert(array_merge($data['update_data'],[
                            'created_at' => date('Y-m-d H:i:s'),
                        ]));
                    }

                }catch (\Exception $exception){
                    Log::info('写入通话记录异常：'.$exception->getMessage());
                }
                usleep(50);
            }else{
                sleep(10);
            }
        }
    }
}
